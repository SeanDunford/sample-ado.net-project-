﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;



public static class Query
{
    public static int Get_Orders(string filterName,
                                     out string error_msg)      //should have been void and updated the address instance 
                                                    //I intended  to set up rules that default.aspx.cs can only query DB
                                                    //through query but retrieve results from Address
                                                    //Query would store all relevant info in address and return that object
                                                   // then the address would have all relevant info name/id/orders
                                                    //in one data structure for easy data mgmt
    {
        address dropDownList = new address();
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        int counter = 0; 
        try
        {
            cn = Setup_Connection();
            rdr = Get_OrderReader(filterName, cn);
            if (rdr.Read())
            {
                counter = (int)rdr["OrderCount"];
            }
            else
                error_msg = "ERROR: lookup Failed";                 //some redundancy here 
            if(counter == 0)
            {error_msg = "ERROR: lookup Failed";
        }
            else
                error_msg = "No Error";
        }
        catch (Exception ex)
        {
            error_msg = "ERROR: " + ex.Message;
        }

        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }

        return counter;

    }

    public static address Get_Address(string filterName,
                                      out string error_msg)  //should have been named get customerName/ID
    {
        address dropDownList = new address(); 
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        int count = 0; 
        error_msg = "";

        try
        {
            cn = Setup_Connection();
            rdr = Get_Reader(filterName, cn);
                   
            while(rdr.Read())
            {
                count++; 
                dropDownList.addToAddress((string)rdr["CompanyName"], (string)rdr["CustomerID"]);
                //every loop save into a data collection then populate dropdownlist in main class 

            }
            if (count == 0)
             {
                error_msg = "Lookup failed";
            }
        }
        catch (Exception ex)
        {
            error_msg = "ERROR: " + ex.Message;
        }

        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return dropDownList;

    }


    private static SqlConnection Setup_Connection()
    {
        String connection_string =
WebConfigurationManager.ConnectionStrings["AddressTable"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;
    }

    private static SqlDataReader Get_OrderReader(string filterName,
                                        SqlConnection cn)
    {
    SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT COUNT(*) AS OrderCount FROM Orders " +
                            //    "WHERE CustomerID = " + "'" + "@filterName" + "'";
                            //could not get param to work, i would have liked to for security purposes
                              "WHERE CustomerID = " + "'" + filterName.ToString() + "'";
            cmd.Parameters.AddWithValue("@filterName",
                                              filterName);
            cmd.Connection = cn;
            return cmd.ExecuteReader();
    }

    private static SqlDataReader Get_Reader(string filterName,
                                        SqlConnection cn)
    {
        
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT CompanyName, CustomerID FROM Customers " +
                                 //"WHERE CustomerID LIKE " + "'" + "@filterName" + "%'";
                                 //could not get param to work, i would have liked to for security purposes
                                  "WHERE CompanyName LIKE " + "'" + filterName.ToString() + "%'";
            cmd.Parameters.AddWithValue("@filterName",
                                          filterName);
            cmd.Connection = cn;
            return cmd.ExecuteReader();
        }
    }

