﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// //address really should have been called NorthwIND info or something more related
/// </summary>
public class address
{
    private List<string> companyName = new List<string>();
    private List<string> companyId = new List<string>();            //i should have used a dictionary instead
                                                                    //implementing a hash would have been more beneficial
                                                                    // no index to manipulate and keep track of
                                                                    //better scalability 
                                                                    //customer name readily available 
                                                                    //getID[customerName] more intutive then selected index manipulation
    private List<string> orders = new List<string>();
    private int index = -1; 

	public address()
	{
        	
	}
    public void addToAddress(string cName, string cId)
    {
        index++;
        companyName.Add(cName);
        companyId.Add(cId);
         
    }
    public string getName(int localIndex)
        {
            return companyName[localIndex]; 
        }
    public string getId(int localIndex)
    {
        return companyId[localIndex];
    }
    public int howMany()
    {
        return index +1; 
    }
}
