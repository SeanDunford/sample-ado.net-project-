﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page
{
    private address collection = null;//address really should have been called NorthwIND info or something more related
    private int count = -1;
    private string tbNameInput = "";
    private int orders;                 //should have been orderNumbers or amountOfOrders
    private string error_msg;
    protected void Page_Load(object sender, EventArgs e)
    {
        tbInput.Focus(); 
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        ddlNames.Enabled = true; 
        if (Session["collection"] != null)
        {
            Session["collection"] = null;
        }
        ddlNames.Items.Clear();
        ddlNames.Items.Add("Select Customer"); 
        tbNameInput = tbInput.Text.Trim();
        tbNameInput = tbNameInput.Replace("\'", "\'\'");
        collection = Query.Get_Address(tbNameInput, out error_msg);
        count = collection.howMany();
        lblError.Text = error_msg;
        if (count > -1)                                  //could this ever be -1? 
        {
            if (count == 0)
            {
                ddlNames.Enabled = false;
                lblError.Text = "There are no customer names matching " + tbInput.Text.ToString()+ "."; 
                                                        //left htis as text box info and not the string var because "b     '" 
                                                        //was printing as just "b". It still delimits some white space but it 
                                                        //includes special chars after whitespace now. 
            }
            else if (count == 1)
            { 
                orders = Query.Get_Orders(collection.getId(0), out error_msg);
                ddlNames.Enabled = false;
                lblError.Text = collection.getName(0) + " has " + orders.ToString() + " orders. ";
            }
            else
            {
                for (int i = 0; i < count; i++)
                {
                    ddlNames.Items.Add(collection.getName(i));
                }
            }

        }
        if (Session["collection"] == null)
        {
            Session["collection"] = collection; 
        }
    }

    protected void ddlNames_SelectedIndexChanged(object sender, EventArgs e)
    {
        collection = (address)Session["collection"];
        if (ddlNames.SelectedIndex >= 1)
        {
            orders = Query.Get_Orders(collection.getId(ddlNames.SelectedIndex - 1), out error_msg);
            lblError.Text = collection.getName(ddlNames.SelectedIndex - 1) + " has " + orders.ToString() + " orders. ";
        }
        else
            lblError.Text = "";
    }


}